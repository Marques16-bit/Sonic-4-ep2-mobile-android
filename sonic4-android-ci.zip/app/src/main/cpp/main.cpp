// Esqueleto nativo (NativeActivity + EGL + OpenGL ES 3.0).
// Se o APK abrir e a tela azul pulsar (e ficar mais clara ao tocar), a cadeia
// GitHub Actions -> NDK -> CMake -> APK arm64-v8a está funcionando.
// Troque drawFrame() pelo loop do jogo.

#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <android/input.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android_native_app_glue.h>

#include <chrono>
#include <cmath>

#ifndef EGL_OPENGL_ES3_BIT
#define EGL_OPENGL_ES3_BIT 0x00000040
#endif
#ifndef EGL_CONTEXT_CLIENT_VERSION
#define EGL_CONTEXT_CLIENT_VERSION 0x3098
#endif

#define LOG_TAG "Sonic4Port"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

struct Engine {
    android_app* app = nullptr;
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    EGLint width = 0;
    EGLint height = 0;
    bool ready = false;
    float touch = 0.0f;
};

void terminateDisplay(Engine& e) {
    if (e.display != EGL_NO_DISPLAY) {
        eglMakeCurrent(e.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (e.context != EGL_NO_CONTEXT) eglDestroyContext(e.display, e.context);
        if (e.surface != EGL_NO_SURFACE) eglDestroySurface(e.display, e.surface);
        eglTerminate(e.display);
    }
    e.display = EGL_NO_DISPLAY;
    e.surface = EGL_NO_SURFACE;
    e.context = EGL_NO_CONTEXT;
    e.ready = false;
}

bool initDisplay(Engine& e) {
    if (e.app->window == nullptr) return false;

    e.display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (e.display == EGL_NO_DISPLAY) {
        LOGE("eglGetDisplay falhou");
        return false;
    }
    if (eglInitialize(e.display, nullptr, nullptr) == EGL_FALSE) {
        LOGE("eglInitialize falhou");
        terminateDisplay(e);
        return false;
    }

    const EGLint configAttribs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RED_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_BLUE_SIZE, 8,
        EGL_DEPTH_SIZE, 16,
        EGL_NONE};
    EGLConfig config = nullptr;
    EGLint numConfigs = 0;
    if (eglChooseConfig(e.display, configAttribs, &config, 1, &numConfigs) == EGL_FALSE ||
        numConfigs < 1) {
        LOGE("eglChooseConfig falhou");
        terminateDisplay(e);
        return false;
    }

    EGLint format = 0;
    eglGetConfigAttrib(e.display, config, EGL_NATIVE_VISUAL_ID, &format);
    ANativeWindow_setBuffersGeometry(e.app->window, 0, 0, format);

    e.surface = eglCreateWindowSurface(e.display, config, e.app->window, nullptr);
    if (e.surface == EGL_NO_SURFACE) {
        LOGE("eglCreateWindowSurface falhou");
        terminateDisplay(e);
        return false;
    }

    const EGLint contextAttribs[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    e.context = eglCreateContext(e.display, config, EGL_NO_CONTEXT, contextAttribs);
    if (e.context == EGL_NO_CONTEXT) {
        LOGE("eglCreateContext falhou");
        terminateDisplay(e);
        return false;
    }

    if (eglMakeCurrent(e.display, e.surface, e.surface, e.context) == EGL_FALSE) {
        LOGE("eglMakeCurrent falhou");
        terminateDisplay(e);
        return false;
    }

    eglQuerySurface(e.display, e.surface, EGL_WIDTH, &e.width);
    eglQuerySurface(e.display, e.surface, EGL_HEIGHT, &e.height);
    eglSwapInterval(e.display, 1);

    LOGI("Superficie %dx%d", static_cast<int>(e.width), static_cast<int>(e.height));
    LOGI("GL_RENDERER: %s", reinterpret_cast<const char*>(glGetString(GL_RENDERER)));
    LOGI("GL_VERSION: %s", reinterpret_cast<const char*>(glGetString(GL_VERSION)));
#if defined(__aarch64__)
    LOGI("ABI: arm64-v8a");
#endif
    return true;
}

void drawFrame(Engine& e, float seconds) {
    const float pulse = 0.5f + 0.5f * std::sin(seconds * 2.0f);
    glViewport(0, 0, e.width, e.height);
    glClearColor(0.05f + 0.25f * e.touch,
                 0.20f + 0.20f * pulse + 0.35f * e.touch,
                 0.55f + 0.25f * pulse,
                 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    eglSwapBuffers(e.display, e.surface);
}

void handleCmd(android_app* app, int32_t cmd) {
    auto* e = static_cast<Engine*>(app->userData);
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (app->window != nullptr) e->ready = initDisplay(*e);
            break;
        case APP_CMD_TERM_WINDOW:
            terminateDisplay(*e);
            break;
        case APP_CMD_WINDOW_RESIZED:
        case APP_CMD_CONFIG_CHANGED:
            if (e->ready) {
                eglQuerySurface(e->display, e->surface, EGL_WIDTH, &e->width);
                eglQuerySurface(e->display, e->surface, EGL_HEIGHT, &e->height);
            }
            break;
        default:
            break;
    }
}

int32_t handleInput(android_app* app, AInputEvent* event) {
    auto* e = static_cast<Engine*>(app->userData);
    if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_MOTION) {
        const int32_t action = AMotionEvent_getAction(event) & AMOTION_EVENT_ACTION_MASK;
        if (action == AMOTION_EVENT_ACTION_DOWN || action == AMOTION_EVENT_ACTION_MOVE) {
            e->touch = 1.0f;
        } else if (action == AMOTION_EVENT_ACTION_UP || action == AMOTION_EVENT_ACTION_CANCEL) {
            e->touch = 0.0f;
        }
        return 1;
    }
    return 0;
}

}  // namespace

extern "C" void android_main(android_app* app) {
    Engine engine;
    engine.app = app;
    app->userData = &engine;
    app->onAppCmd = handleCmd;
    app->onInputEvent = handleInput;

    const auto start = std::chrono::steady_clock::now();

    while (true) {
        int events = 0;
        android_poll_source* source = nullptr;
        const int timeout = engine.ready ? 0 : -1;

        while (ALooper_pollOnce(timeout, nullptr, &events, reinterpret_cast<void**>(&source)) >= 0) {
            if (source != nullptr) source->process(app, source);
            source = nullptr;
            if (app->destroyRequested != 0) {
                terminateDisplay(engine);
                return;
            }
        }

        if (app->destroyRequested != 0) {
            terminateDisplay(engine);
            return;
        }

        if (engine.ready) {
            const std::chrono::duration<float> elapsed = std::chrono::steady_clock::now() - start;
            drawFrame(engine, elapsed.count());
        }
    }
}
