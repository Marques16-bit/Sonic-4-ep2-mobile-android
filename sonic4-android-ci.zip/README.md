# Sonic 4 Port (Android, arm64-v8a)

Projeto C++ (CMake) compilado 100% no GitHub Actions. Nada precisa ser compilado no celular.

## Como usar
1. Extraia o zip na **raiz** do repositório (a pasta `.github` precisa ficar na raiz).
   Se o gerenciador de arquivos não mostrar `.github`, ative "mostrar arquivos ocultos".
2. Faça commit/push na branch `main` (ou `master`).
3. No GitHub: aba **Actions** -> **Android APK (arm64-v8a)** -> abra a execução.
   (Também dá para rodar manualmente em **Run workflow**.)
4. Quando ficar verde, role até **Artifacts** e baixe `sonic4-android-arm64-v8a-debug`
   (um zip com o `.apk` dentro).
5. Se der erro, baixe `logs-de-erro` ou copie as últimas linhas do passo vermelho.

## APK direto na Release
Crie uma tag que começa com `v` (ex.: `v0.1.0`). O workflow publica o `.apk` na aba **Releases**,
e dá para baixar o APK direto, sem zip.

## Onde colocar o código do porte
- `app/src/main/cpp/game/` -> tudo que for `.c`, `.cc`, `.cpp` ali entra no build sozinho.
- `app/src/main/cpp/main.cpp` -> ponto de entrada (NativeActivity + EGL + GLES 3.0).
  Hoje só pinta a tela de azul; troque `drawFrame()` pelo loop do jogo.
- `app/src/main/cpp/CMakeLists.txt` -> adicione bibliotecas externas aqui (ex.: `add_subdirectory(...)`).

## Versões
- NDK: sempre a mais recente disponível no sdkmanager (o workflow descobre sozinho).
- CMake 3.22.1, Gradle 8.9, Android Gradle Plugin 8.7.3, JDK 17.
- minSdk 26, targetSdk 35, só `arm64-v8a`.
- O APK sai assinado com a chave debug (instala normalmente, mas não serve para a Play Store).
